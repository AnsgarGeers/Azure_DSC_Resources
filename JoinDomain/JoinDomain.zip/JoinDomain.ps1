﻿configuration JoinDomain
{ 
   param 
    ( 
        [Parameter(Mandatory=$true)]
        [String]$DomainName,

        [Parameter(Mandatory=$true)]
        [PSCredential]$AdminCreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xStorage, xPendingReboot, xComputerManagement, PSDesiredStateConfiguration
    
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true
            AllowModuleOverWrite = $true       
        }
        WindowsFeature NET-Framework-Core
        {
            Ensure = "Present"
            Name = "NET-Framework-Core"
        }
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }
        xDisk AddDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            FSLabel = "Data"
        }
        xComputer ComputerConfiguration
        {
          Name = $env:COMPUTERNAME
          DomainName = $DomainName
          Credential = $DomainCreds
        }
        xPendingReboot Reboot
        { 
            Name = "RebootServer"
            DependsOn = "[xComputer]ComputerConfiguration"
        }
    }
} 
