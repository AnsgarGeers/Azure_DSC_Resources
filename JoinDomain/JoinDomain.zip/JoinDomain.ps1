﻿configuration JoinDomain
{ 
   param 
    ( 
        [Parameter(Mandatory=$true)]
        [String]$DomainName,

        [Parameter(Mandatory=$true)]
        [PSCredential]$AdminCreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xStorage, xPendingReboot, xComputerManagement, PSDesiredStateConfiguration
    
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true
            AllowModuleOverWrite = $true       
        }
        xComputer ComputerConfiguration
        {
          Name = $env:COMPUTERNAME
          DomainName = $DomainName
          Credential = $DomainCreds
        }
        xPendingReboot Reboot1
        { 
            Name = "RebootServer"
            DependsOn = "[xComputer]ComputerConfiguration"
        }
    }
} 
